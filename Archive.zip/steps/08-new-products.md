# 08 · New products

**Goal:** an unknown barcode can become a real listing — brand, name and type — by
two photos or by typing.

## Tasks

1. `app/new/page.tsx` — server. `?barcode=…`.
   - `copy.newProduct.heading` / `body(barcode)`: we have the barcode, but a barcode
     on its own isn't a product (R9).
   - `copy.newProduct.wouldBeTitle(n)` using a live count + 1, not a hardcoded number.
   - Two option cards: **Take two photos** (tagged quickest, pushed) and **Add it
     yourself** (for when the front is awkward — pump bottles, glare, a name on the
     lid).
   - A free exit: "Not now".

2. `app/new/photos/page.tsx` — client. Two numbered `components/ShotCard.tsx`:
   - Card 1, the ingredients list. Once taken, ticked, showing what it produced
     (`copy.newProduct.shotOneDone(n)`). Proof the first photo worked before she
     commits to a second.
   - Card 2, the front. States *why*: `copy.newProduct.shotTwoWhy`.
   - Then "Create the listing", and `copy.newProduct.skipFront`.

3. `app/api/scan/front/route.ts` — `allowWrite(ipHash, 'scan')`, Vision OCR on the
   front, return a best guess at `{ brand, name, type }`. Match the brand against the
   373-brand list; infer the type by keyword (`shampoo`, `conditioner`, `gel`, `curl
   cream`…) and return it as a **suggestion only**.

4. `app/new/add/page.tsx` — client. The form from step 05, prefilled from the front
   OCR when it exists. Barcode row first, stated as already attached
   (`copy.newProduct.barcodeAttached`). Brand, name, `TypeSelect`, size.
   `copy.newProduct.youCheck` under it.

5. `createProduct()`, then link the ingredients scan to the new product id and call
   `supersede_product_ingredients` so the listing arrives with a verdict.

## Done when

- An unknown barcode → two photos → a listing with brand, name, type, the barcode
  attached and a verdict, in one pass.
- The manual route produces a listing with the barcode attached and no verdict, and
  says so.
- Front-of-bottle OCR prefills the three fields and every one of them is editable.
- The new row has `verified_at` null and `source = 'manual'`.
- Scanning the same barcode again finds it.

## Don't

- **Don't save an OCR-guessed type.** Prefill it, make her confirm it. Type drives
  which alternatives get recommended.
- **Don't trust front-of-bottle text.** It's a marketing layout — it'll catch "NEW!",
  a fragrance name, a claim. Prefilled and checked is right; auto-saved is not.
- **Don't publish on submit** (R10).
- **Don't let new brands into the autocomplete on first submission.** Hold them in a
  queue; an anonymous write path with an open vocabulary gets polluted fast.
- **Don't forget the rate limit.** `add_product` is 5/hour per IP hash.
