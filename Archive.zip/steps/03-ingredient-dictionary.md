# 03 · Ingredient dictionary

**Goal:** `match_ingredient()` resolves the overwhelming majority of real ingredient
strings, and you know which ones it misses.

Nothing visible ships. Step 04's quality is capped by this step: an empty dictionary
means every verdict is Clear, because nothing matches anything.

## Tasks

1. Populate `public.ingredients` from whatever you have now — your existing matcher's
   lists, one row per ingredient, with `category` and (for silicones)
   `water_soluble`. The six categories are `sulfate`, `silicone`, `drying_alcohol`,
   `mineral_oil`, `wax`, `cg_safe`; everything else is `neutral`.

   Get these two right, because they're the pair that decides a verdict on their own:
   ```sql
   insert into public.ingredients (inci_name, category, water_soluble) values
     ('Dimethicone',  'silicone', false),   -- Skip
     ('Dimethiconol', 'silicone', true);    -- Clear
   ```

2. Move your spelling variants into `public.ingredient_aliases`. Anything your old
   normalization special-cased is an alias row now, with `source = 'manual'`.

3. Write a one-off audit script (`scripts/audit-dictionary.ts`). For every distinct
   ingredient string in `products.ingredients_text`, split on commas, run each piece
   through `match_ingredient()`, and print the ones that come back empty, ordered by
   how often they occur.

4. Work the top of that list. The long tail doesn't matter; the strings that appear
   hundreds of times do.

5. Re-run the audit until the unmatched share is small enough that you'd trust a
   verdict. Keep the script — from step 04 onwards the same query over
   `scan_ingredients where ingredient_id is null` is your live backlog.

## Done when

- The audit reports a small unmatched share, and every high-frequency unmatched
  string is either in the dictionary or deliberately `neutral`.
- `select * from match_ingredient('CETEARYL ALCOHOI');` returns cetearyl alcohol via
  `alias` or `fuzzy`.
- `select * from match_ingredient('Dimethicon');` returns **both** dimethicone and
  dimethiconol. This is what makes the R3 pick card possible — if only one comes
  back, `scan_open_questions` can never fire.

## Don't

- **Don't normalize in TypeScript.** `normalize_ingredient()` lives in the database
  so the same rules apply from the app, from this script, and from SQL you run by
  hand. Two implementations will drift and you'll debug the difference for a day.
- **Don't file an ingredient as `cg_safe` just because it isn't flagged.** `neutral`
  is the default; `cg_safe` means you'd actively tell someone it's good, and it shows
  up in "worth knowing" on a Clear verdict.
- **Don't guess `water_soluble` on silicones.** It's the difference between Clear and
  Skip. If you're not sure, leave the ingredient out rather than file it wrong.
