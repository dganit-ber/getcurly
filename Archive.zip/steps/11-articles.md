# 11 · Articles

**Goal:** `/read` exists, and two of its pieces are generated from data only you have.

This is where affiliate revenue actually compounds: articles pull search traffic and
an in-article mention converts without any pressure on a verdict.

## Tasks

1. `app/read/page.tsx` — index. Kicker, title, excerpt. Three to start.

2. `app/read/[slug]/page.tsx` — the article. Render `body_md`, and inline product
   blocks from `article_products` (join by `article_id`, ordered by `sort_order`).
   The affiliate disclosure sits with the product block, not in the footer.

3. Write the three that the app already knows the answer to:
   - **"Not every silicone is a problem"** — soluble vs non-soluble, straight out of
     your `water_soluble` column. This is the piece that explains the pick card.
   - **"Read an ingredients list in thirty seconds"** — position-as-concentration
     reasoning, which is the same logic the verdict screen uses.
   - **"The most-skipped shampoos this month"** — generated from
     `most_skipped_this_month`. A page only you can write, and the one that gets
     linked to.

4. Wire the two views:
   - `most_skipped_this_month` → the data article, refreshed monthly.
   - `recent_reformulations` → a "brands that quietly reformulated this year" piece,
     which is the payoff for step 07's history keeping.

5. Three article teasers on the home page, titles only, no excerpts.

## Done when

- `/read` lists published articles; unpublished ones 404 (the RLS policy already
  requires `published_at <= now()`).
- The data article renders from the view, not from hardcoded numbers.
- An in-article product block links through with its disclosure beside it.
- Home shows three titles.

## Don't

- **Don't put the disclosure only in the footer** on an article with product blocks.
  It goes with the links, before the click.
- **Don't write a generic "best curly hair products" listicle.** Every CG site has
  one. The two data-driven pieces are the ones nobody else can publish.
- **Don't let an article recommend an unconfirmed product** — same rule as step 10.
- **Don't hardcode the monthly numbers.** A stale "most skipped this month" is worse
  than not having the page.
