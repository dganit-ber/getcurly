# 07 · The mismatch path

**Goal:** when she says our list is wrong, she photographs the real one and gets a
diff — and the record is corrected without losing its history.

## Tasks

1. "It doesn't match" goes to `/scan?mode=label&for=[productId]`. The scan screen
   picks up `for` and shows the rescan framing instead of the normal one:
   `copy.rescan.title`, `copy.rescan.body`, and `copy.rescan.whyTitle` / `why` —
   because asking for a second photo needs a stated reason.

2. `app/api/scan/label/route.ts` gains the `for` case: `recordLabelScan({ productId,
   kind: 'recheck' })`. That already calls `supersede_product_ingredients` and
   `maybe_promote_product` inside one transaction, so the old list is versioned and
   the new one becomes current.

3. After a `recheck` scan, redirect to `/p/[id]/changed` rather than `/s/[scanId]`.

4. `app/p/[id]/changed/page.tsx` — server. `getLatestDiff(id)`:
   - `gone` / `new` / `moved` rows with positions named, via `components/DiffRow.tsx`.
     Moves matter as much as additions — position is roughly concentration.
   - `copy.diff.unchanged(n)` for the rest. Nobody compares two 37-item lists.
   - Then what it means for the verdict, in words: *"Still Skip — but for one reason
     now, not two."* A diff that doesn't interpret itself is just data.
   - Then `copy.diff.recordTitle` / `record` — her read is the record, the old list
     is kept.

5. `logCheck({ result: 'mismatch', scanId })` once the rescan exists. The database
   won't accept a mismatch without a `scan_id`, which is the constraint that enforces
   this whole step.

6. The no-photo exit: `copy.rescan.flagWithoutPhoto` → `logCheck({ result: 'stale' })`
   → back to the verdict. Weaker signal, still recorded.

## Done when

- "It doesn't match" cannot reach the diff without a photo.
- After a rescan of a changed product, the diff shows the real differences with
  positions, and the verdict line explains what changed about the answer.
- `product_ingredient_versions` has two rows for that product, one with
  `superseded_at` set.
- The no-photo flag increments `stale_flag_count` and changes nothing else.

## Don't

- **Don't let a `stale` flag rewrite a verdict or the ingredient list.** It's someone
  saying "this looks out of date" with no evidence. Surface it as a stronger caution
  after a few, and as a queue to yourself — that's all.
- **Don't overwrite the old list.** `supersede_product_ingredients` versions it.
  Reformulation history is the most interesting thing this app collects and nobody
  else has it; it feeds step 11.
- **Don't show every row of both lists.** Four differences and a count.
- **Don't skip the "why we need the photo" box.** People hand over a photo when they
  understand what it buys them.
