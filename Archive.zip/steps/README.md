# The 11 steps

One step per file. Do them in order, and **deploy at the end of each one** — every
step is written to leave the app in a shippable state, which is the only way to
rewrite something that's already live without a long broken window.

Each file has the same four parts:

- **Goal** — one sentence. If the step doesn't achieve this, it isn't done.
- **Tasks** — concrete, with file paths. Follow `SPEC.md` for content and
  `lib/copy.ts` for wording.
- **Done when** — checkable on a phone. Not "it compiles".
- **Don't** — the specific traps for this step. These are the parts most likely to
  get quietly wrong.

Rule numbers (R1–R14) refer to the hard rules in `CLAUDE.md`. When a step and a rule
appear to conflict, the rule wins.

| # | Step | Ships |
|---|---|---|
| 01 | [Schema](01-schema.md) | nothing visible — the foundation |
| 02 | [Theme and shell](02-theme-and-shell.md) | new look over old pages |
| 03 | [Ingredient dictionary](03-ingredient-dictionary.md) | nothing visible — matching quality |
| 04 | [The label flow](04-label-flow.md) | scan → verdict, the core of the app |
| 05 | [The optional tail](05-optional-tail.md) | edit the list, name the bottle |
| 06 | [Barcode](06-barcode.md) | two-second answers |
| 07 | [The mismatch path](07-mismatch-path.md) | reformulation diffs |
| 08 | [New products](08-new-products.md) | the library grows |
| 09 | [Library](09-library.md) | browse and search |
| 10 | [Affiliates](10-affiliates.md) | revenue, model A only |
| 11 | [Articles](11-articles.md) | content and SEO |

Steps 01 and 03 ship nothing a user can see. Do them anyway and do them first —
every step after 04 is built on the assumption that `type` is a closed list and the
ingredient dictionary is good enough to match against.
