# 04 · The label flow

**Goal:** she photographs an ingredients list and gets a verdict, with no input asked
of her on the way.

This is the core of the app. Get it right before touching barcodes.

## Tasks

1. `app/scan/page.tsx` — client. Label mode only for now (barcode arrives in step 06,
   but build the `ModeSwitch` with the barcode tab present and disabled so the layout
   doesn't move later).
   - `components/Viewfinder.tsx`: `<input type="file" accept="image/*"
     capture="environment">` behind the tall reticle. That opens the rear camera on a
     phone and a file picker on desktop, with no permissions dance.
   - Copy from `copy.scan`. Note `copy.scan.labelReassurance` — reassurance, not a
     warning (R4).

2. `app/api/scan/label/route.ts`:
   ```
   hashIp(req) → allowWrite(ipHash, 'scan')   // 429 if false
   validate: mime in (jpeg, png), size <= 8MB
   Vision OCR → raw text
   split the ingredient paragraph on commas / bullets / newlines
   for each piece, in order: match_ingredient() → build a ScanItemInput
     - top candidate becomes ingredient_id / resolved_name / category / water_soluble
     - keep the full candidate array on the row (that's what feeds R3)
   if items.length < 10 → return the 'partial' error, no scan row, no verdict
   if items.length === 0 → return the 'noText' error
   recordLabelScan({ items, rawOcr, ipHash }) → { scanId, verdict }
   ```
   Do the matching in one round trip if you can — a `select … from
   match_ingredient(x)` per ingredient is 37 queries per scan. A single call passing
   an array, or a small server-side cache of the dictionary, is fine.

3. Processing state. Narrate the real steps from `copy.scan.reading.steps` and show
   the ingredient count. Show the **cleaned** list forming, never the raw OCR string
   with its typos — telling her the machine misread "Cetearyl Alcohoi" advertises a
   failure she never needs to know about.

4. `app/s/[scanId]/page.tsx` — server. Per `SPEC.md`:
   - `VerdictPill` + one sentence.
   - `getOpenQuestions(scanId)`. **Empty array is the normal case → render nothing.**
     One row → `components/PickCard.tsx` with both candidates named and what each
     means (R3).
   - Identity: `looksLike(name)` with a "not right?" link when the fingerprint
     matched, or `unknownProduct` plus the add prompt immediately underneath.
   - Skip: `getVerdictReasons(scanId)` → `FlaggedIngredient` rows, three lines each
     (name, group + position, `copy.why[category]`), then the cleared groups in one
     row. Clear: five groups ticked, then "worth knowing".
   - "What we counted" preview — six rows, a count, a link to step 05's screen, and
     `copy.verdict.misreadNote` (R2: this is the only place misreads are mentioned).
   - Evidence note, then scan another / save / "tell us what went wrong".

5. `app/api/scans/[id]/resolve/route.ts` — she tapped a candidate on the pick card.
   `reviseScan({ resolution: 'user_picked' })`, then redirect to the **new** scan id.

6. All three failure states from `copy.scan.errors`, each with its own action.

## Done when

- Photograph a sulfate shampoo on a phone → Skip, with the sulfate named and its
  position, in under five seconds. No tap between the shutter and the answer.
- Photograph a CG-safe conditioner → Clear.
- A photo of the *front* of a bottle → the `partial` or `noText` error, not a verdict.
- A scan whose ambiguous word can't change the outcome shows **no** pick card.
- A scan where dimethicone/dimethiconol decides it shows the card, and tapping the
  other candidate flips the verdict and lands on a new URL.

## Don't

- **Don't render a verdict when fewer than ~10 ingredients came back.** A confident
  wrong Clear on a shampoo someone then buys is the worst thing this app can do.
- **Don't show confidence, scores, or "we're unsure" on any row** (R2). The
  candidates live on the row in the database for `scan_open_questions` to use; they
  are not UI.
- **Don't ask anything before the verdict** — not the product name, not a
  confirmation, not an account (R1).
- **Don't mutate a scan.** The resolve handler forks (`reviseScan`); the original row
  stays as evidence, and the pair is your training data (R11).
- **Don't re-sort the ingredients.** Label order is concentration order.
