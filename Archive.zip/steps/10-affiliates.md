# 10 · Affiliates

**Goal:** links appear at the only moment she wants them, and the ranking promise in
the disclosure is literally true.

Model **A** only. B and C go behind a config value so switching later isn't a rewrite.

## Tasks

1. `AFFILIATE_MODEL=a` in the environment. Read it once, server-side, pass it down.

2. Populate `retailers` and `affiliate_links` for the products you have programmes
   for. `product_best_link` (the view) gives you the cheapest in-stock link per
   product.

3. `components/AlternativesBlock.tsx` — model-aware, and it owns its disclosure text.
   Per the matrix in `SPEC.md`:
   - **Skip verdict** (barcode or label) → `getAlternatives(productId, 2)`,
     `copy.affiliate.alternativesLabel`, two rows, `copy.affiliate.disclosure`.
   - **Clear, known product** → the quiet `copy.affiliate.whereToBuy` line only.
   - **Clear, unknown product** → **no buy link at all.**
     `copy.affiliate.whileYoureHere*` — two confirmed products, framed as "in case
     you're still looking", explicitly not a replacement for the bottle that just
     passed. You can't sell a product you can't name.
   - **Barcode Clear** → nothing beyond the stockist line.

4. The footer promise, on every page: `copy.affiliate.footerPromise`.

5. `/method` — how the method works, how verification works, and the affiliate
   promise stated properly. It's the page you link to when someone asks whether the
   verdicts are for sale.

## Done when

- A Skip shows exactly two alternatives, both `verified_at is not null`, in the order
  the function returned them.
- A Clear with an unknown product shows recommendations and **no** buy link.
- A Clear with a known product shows a stockist line and no alternatives.
- The disclosure says "ranked by match, then price — never by commission", and that's
  true of the query.
- Setting `AFFILIATE_MODEL=b` adds the picks strip and the nav item without touching
  a component's logic.

## Don't

- **Don't re-sort `cg_safe_alternatives()`.** The order *is* the rule. Sorting it in
  the component makes the disclosure a lie.
- **Don't recommend an unconfirmed product.** Seed rows can be searched, not sold.
  The function already filters; don't add a fallback that loosens it when it returns
  fewer than two rows — showing one is fine, showing an unchecked one is not.
- **Don't show more than two.** A wall of products reads as a storefront and spends
  the credibility the verdict just built.
- **Don't put alternatives on a Clear** (R12).
- **Don't let a commission ever affect a verdict, a ranking, or which ingredients get
  flagged.** This is the whole asset.
