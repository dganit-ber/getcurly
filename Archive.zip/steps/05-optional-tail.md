# 05 · The optional tail

**Goal:** she can check the list and name the bottle — and it's obvious that neither
is required.

## Tasks

1. `app/s/[scanId]/list/page.tsx` — client.
   - `getScanIngredients(scanId)`, ordered by `pos`. Render **resolved** names, not
     `raw_text` (R5).
   - Flat rows: number, name, group pill where we matched one, delete. No badges of
     doubt, no underlines, no icons of uncertainty (R2).
   - Twelve rows, then `copy.list.showRest(n)`.
   - Tap a row to edit inline. "Add one we missed" in the header — the real failure
     isn't a misread word, it's a line the photo cut off.
   - `copy.list.recompute` as the primary button, **disabled until something actually
     changed**. Otherwise it invites a pointless round trip.
   - Footer: `copy.list.notRequired`.

2. `app/api/scans/[id]/list/route.ts` — `allowWrite(ipHash, 'edit_list')`, then
   `reviseScan({ edits, removed, resolution: 'user_typed' })`, redirect to the new
   scan id.

3. `app/s/[scanId]/name/page.tsx` — client.
   - Candidates from the ingredient fingerprint. The app **proposes**: "36 of 37
     ingredients identical — is this Smooth Shine Shampoo?" with one tap to confirm.
     Match on a hash of the normalised, ordered list, with a near-match tolerance.
   - Two more candidates from brand/name fuzzy matching below it.
   - Then the add form: barcode row (stated as attached if there is one),
     `BrandAutocomplete`, product name, `TypeSelect` (**required**), size (optional).
   - `copy.identify.optional` at the top, and a visible skip at the bottom.

4. `components/TypeSelect.tsx` — a plain `<select>` from `getProductTypes()`. Closed
   list (R9).

5. `components/BrandAutocomplete.tsx` — the 373 brands, fuzzy, and **show the near
   misses**. That's what the fuzzy matching is for; hiding it behind exact prefixes
   wastes it.

6. `app/api/products/route.ts` — `allowWrite(ipHash, 'add_product')`, then
   `createProduct()`. Nothing is verified on creation (R10).

## Done when

- From a verdict, two taps reach the list and one edit re-runs it to a new verdict on
  a new URL.
- The re-run button is dead until something changes.
- A scan whose list matches a stored product proposes that product by name.
- The add form refuses to submit without a type.
- Skipping both steps leaves the verdict exactly as it was.

## Don't

- **Don't show `raw_text` anywhere.** If OCR read "Cetearyl Alcohoi" and we matched
  cetearyl alcohol, she sees cetearyl alcohol. That's what was counted.
- **Don't gate the verdict behind either screen** (R1).
- **Don't let the type field be free text, and don't save an OCR-guessed type without
  her tap.** A shampoo filed as a conditioner sends the wrong product to the next
  person.
- **Don't publish a new product immediately.** It waits for a second agreeing scan,
  and the UI says so (`copy.newProduct.notLiveYet`).
