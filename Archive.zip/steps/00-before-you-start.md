# 00 · Before you start

Not a step. Read this once.

## What you're changing

The app is live at getcurly.ink and the scan pipeline works. What's being rewritten is
the **shape of the flows** and the **look**. The Vision integration, the ingredient
matching logic and the Open Beauty Facts import all survive — see the "What survives"
and "What goes" sections of `REWRITE-PLAN.md`.

## Rules over instructions

`CLAUDE.md` holds 14 hard product rules, referenced in these steps as R1–R14. They are
decisions already made after several rounds of review. Where a step and a rule seem to
disagree, the rule wins. Where something isn't covered by either, the question to ask
is: *does this make her do work before she gets her answer?* If yes, it's wrong.

## The three that get broken most often

1. **R1 — verdict in one action.** Every screen after the camera is optional. The
   moment something stands between the shutter and the answer, the app has lost its
   reason to exist.
2. **R2 — never surface OCR confidence.** No badges, no scores, no "we're not sure"
   on individual rows. One general sentence, once. The candidates live in the database
   for `scan_open_questions` to use; they are not UI.
3. **R7 — seed data gets no verdict.** Call `product_confidence()` before rendering a
   verdict pill on any product page. An unchecked Open Beauty Facts row gets
   different copy, not a green tick.

## Working rhythm

- **One step at a time.** Finish it, deploy it, check it on a phone, then start the
  next. Don't open two steps at once.
- **Deliver whole files**, not diffs or fragments.
- **Named arrow exports** (`export const X = () => {}`), except Next.js pages and
  layouts which need `export default`.
- Copy comes from `lib/copy.ts`. Colours come from the theme tokens. Neither gets
  inlined into a component.

## Check yourself at the end of every step

- Does it work on a phone, in both light and dark?
- Does anything ask her for input before she has a verdict?
- Does any screen mention how confident the matcher was?
- Does any product page render a verdict without checking the confidence tier first?
