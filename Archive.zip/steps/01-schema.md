# 01 · Schema

**Goal:** the database can support every flow in `SPEC.md`, and `products.type` is a
closed list.

Nothing visible ships. This is the foundation for everything after it.

## Tasks

1. Run `db/getcurly-schema.sql` in the Supabase SQL editor. One transaction, safe to
   re-run. It adds 15 tables and ~20 functions, and adds columns to the existing
   `products` table without touching your data.

2. Find out what `products.type` currently holds:
   ```sql
   select type, count(*) from public.products group by 1 order by 2 desc;
   ```

3. Map every value onto a `product_types.slug`. Write the updates explicitly — don't
   guess with a fuzzy match:
   ```sql
   update public.products set type = 'shampoo'     where type in ('Shampoo','shampoo','SHAMPOO');
   update public.products set type = 'conditioner' where type in ('Conditioner','conditioner');
   -- …one line per distinct value you found…
   update public.products set type = 'other'
    where type not in (select slug from public.product_types);
   ```

4. Add the foreign key. This is the point of the step:
   ```sql
   alter table public.products
     add constraint products_type_fkey
     foreign key (type) references public.product_types (slug);
   ```

5. Set the environment variables in Vercel (list at the end of `REWRITE-PLAN.md`).
   `IP_HASH_SALT` must be a long random string, and must never change once set — if
   it changes, every existing rate-limit record silently detaches from its IP.

6. Sanity-check the functions against real rows:
   ```sql
   select tier, checked_at, checks, score from public.product_confidence(<a scanned product id>);
   select tier from public.product_confidence(<an obf product id>);   -- expect 'seed_only'
   ```

## Done when

- The foreign key exists and the migration re-runs clean.
- `product_confidence()` returns `seed_only` for an unscanned Open Beauty Facts row.
  This is the check that matters — R7 depends on it.
- `select count(*) from public.product_types;` returns 15.

## Don't

- **Don't skip the foreign key.** Free-text `type` is the single thing that breaks
  recommendations later, and it breaks them silently: `cg_safe_alternatives()` joins
  on `type` and `family`, so a typo'd type just returns nothing.
- **Don't drop or rename `cg_approved`.** It's unused by the new code but it's your
  old verdict column — leave it until the rewrite is finished and you've confirmed
  nothing reads it.
- **Don't rename `scan_ingredients.pos` to `position`.** `position` is reserved in a
  Postgres `returns table` list and three functions won't compile.
