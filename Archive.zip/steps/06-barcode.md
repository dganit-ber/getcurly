# 06 · Barcode

**Goal:** a barcode gives an answer in about two seconds, with its age attached — and
unchecked seed data gives no verdict at all.

## Tasks

1. `components/Viewfinder.tsx` gains barcode detection, client-side:
   ```ts
   if ('BarcodeDetector' in window) { /* native */ }
   else { /* zxing-wasm */ }
   ```
   Feature-detect properly — iOS Safari may not have it. Run it against the same
   video stream as the label mode; the reticle is short for a barcode, tall for a
   paragraph. No upload, no Vision call, no cost.

2. `app/scan/page.tsx` — enable the barcode tab and make it the default.
   `?mode=barcode|label`. On a decode, look the barcode up (a Server Component or a
   plain read with the anon key — reads are open, no handler needed) and navigate:
   - found → `/p/[id]?from=barcode`
   - not found → `/new?barcode=…`

3. `app/p/[id]/page.tsx` — server. In this order:
   - `getConfidence(id)` **first**.
   - `mayShowVerdict(confidence)` false → **no `VerdictPill` at all.** Render
     `copy.barcode.seedOnlyTitle` / `seedOnly`, the ingredients as a preview, and
     "read the label" as the primary action (R7).
   - true → `VerdictPill`, then `CautionNote`
     (`copy.barcode.cautionTitle` / `caution`), then identity, then
     `components/LastChecked.tsx`: `copy.barcode.lastCheckedLabel`, the date, and
     `lastCheckedSub(ago, people)`. Every scan, every time, for everyone (R6).
   - The stored list, first six rows plus a count.
   - `copy.barcode.checkQuestion` with three buttons: **It matches** → POST then
     `/p/[id]/checked`; **It doesn't match** → `/scan?mode=label&for=[id]` (step 07);
     **Not now** → nothing happens, no guilt.

4. `app/api/products/[id]/check/route.ts` — `allowWrite(ipHash, 'check')`, then
   `logCheck({ result: 'match' })`. The trigger moves `last_checked_at` and
   `check_count` for you.

5. `app/p/[id]/checked/page.tsx` — the confirmation. Two dated rows, before and
   after, so she can see what her tap did. `copy.barcode.checked*`. A toast gives her
   nothing; a changed date gives her a reason to do it again.

## Done when

- A known barcode → verdict, caution and a last-checked date in about two seconds.
- An unscanned Open Beauty Facts barcode → **no verdict pill**, the unchecked copy,
  and "read the label" as the primary button. Test this one explicitly; it's the
  failure that would cost the most.
- "It matches" moves the date to today, and reloading the page shows the new date.
- A barcode we don't have → `/new?barcode=…`.
- Works on iOS Safari and on Android Chrome.

## Don't

- **Don't render a verdict before calling `product_confidence()`.** Every single
  time, on every entry point to a product page.
- **Don't collapse the two dates into one.** `ingredients_read_at` is when the list
  came from a photo; `last_checked_at` is when a person confirmed it. "Read in March,
  checked today" is a much stronger claim than either alone.
- **Don't show alternatives on a barcode Clear** (R12). She's holding something that
  works; pushing product there is what makes the app feel like a shop.
- **Don't send the barcode to the server to decode it.** It resolves on the device in
  milliseconds and that's most of why this path is worth building.
- **Don't hide the caution behind a tap.** It sits directly under the verdict, above
  any reasoning.
