# 09 · Library

**Goal:** `/library` replaces the parked `/search`, and the difference between a
confirmed product and a seed row is visible at a glance.

## Tasks

1. `app/library/page.tsx` — server.
   - Confirmed products by default: `verified_at is not null`, newest checks first.
   - Filter by type, using `product_types` grouped by `family`.
   - Each row: brand, name, type, `VerdictPill`, and the **last checked date**. Not a
     colour-intensity badge — the old freshness-by-saturation idea is gone, because a
     date she can read beats a badge only you can decode.

2. Search. Brand and name, fuzzy — reuse the trigram indexes. Unconfirmed seed rows
   *are* reachable by search, but visibly marked as unchecked and without a verdict
   (R7, same rule as the barcode screen).

3. `app/library/[type]/page.tsx` for the type filters, so they're linkable and
   indexable.

4. Retire `/search`: delete the `UnderConstruction` component and redirect
   `/search` → `/library` permanently. Put "Library" back in the nav.

5. Product rows link to `/p/[id]`, which already handles both tiers from step 06.

## Done when

- `/library` lists confirmed products with their last-checked dates.
- Searching finds a seed row, and that row shows no verdict and says nobody has
  checked it.
- `/search` redirects.
- One word is used for this thing everywhere — nav, buttons, copy. Pick "Library" and
  don't also say "Browse" on the home page.

## Don't

- **Don't show unconfirmed rows in the default list.** Findable by search, yes.
  Presented as the library, no.
- **Don't bring back intensity-as-freshness.** Hue carries the verdict; recency is a
  date.
- **Don't paginate by loading everything.** ~1,500 rows now, but the seed import can
  grow.
