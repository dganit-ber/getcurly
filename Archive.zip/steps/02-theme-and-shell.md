# 02 · Theme and shell

**Goal:** the new visual direction is live over the existing pages, and the three
primitives every later step needs exist.

Ship this before building any new screen. It looks half-migrated for a few days —
that's fine, and it de-risks everything after, because you find the theme problems
once instead of eleven times.

## Tasks

1. `app/globals.css`:
   ```css
   @import "tailwindcss";
   @import "./theme.css";
   ```
   Copy `app/theme.css` in as-is. Delete the old kelp-green variables and the
   Fraunces/Karla font setup in the same commit — leaving both sets live is how you
   end up with a page that's half one palette.

2. `app/fonts.ts` as provided. Wire the variables onto `<html>` in `app/layout.tsx`,
   then switch the two `@theme inline` font stacks over to `var(--font-gabarito)` /
   `var(--font-hanken)` as the comment in that file says.

3. Theme toggle. A client component that sets `data-theme` on
   `document.documentElement` and persists to `localStorage` in a try/catch. Three
   states: unset (follow the system), `light`, `dark`.

4. Build three primitives, because every screen from step 04 onwards uses them:
   - `components/VerdictPill.tsx` — `clear | skip`. Pill, icon, word. The **only**
     place `--clear` and `--skip` appear in the codebase.
   - `components/IngredientRow.tsx` — number, name, optional group pill, optional
     delete. Read-only and editable variants.
   - `components/WaveDivider.tsx` — or just the `.wave-top` class on section
     elements. It's a curl, not decoration.

5. Retheme the pages that already exist (home, the current scan page) with the new
   tokens. Don't restructure them yet — that's step 04.

## Done when

- Light and dark both look deliberate on a phone, including the system-default state
  where no `data-theme` attribute is set at all.
- `grep -rn '#[0-9a-fA-F]\{6\}' app components` returns nothing outside `theme.css`.
- `VerdictPill` renders both verdicts legibly in both themes.

## Don't

- **Don't drop `inline` from `@theme inline`.** Without it Tailwind copies the
  resolved value instead of the `var()` reference, and dark mode silently stops
  working while light mode looks perfect.
- **Don't define a colour only inside a dark block.** Every token gets its value in
  the bare `:root` first. A colour that exists only under `[data-theme="dark"]`
  renders as nothing in the system-default state, which is what most people see.
- **Don't use colour as the only signal.** Clear and Skip always carry an icon and
  the word.
- **Don't put a hex value in a component.** Not once, not temporarily.
