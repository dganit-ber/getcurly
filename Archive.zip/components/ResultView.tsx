import Link from "next/link";
import { AccordionSection } from "@/components/AccordionSection";
import { Coil } from "@/components/Coil";
import { IngredientRow } from "@/components/IngredientRow";
import { OcrOutcome } from "@/app/api/context/ResultContext";

const GrowLine = () => (
  <p className="mt-6 text-center text-[13px] text-muted">
    Help us grow — add this product to our{" "}
    <Link href="/products" className="font-bold text-brand">
      database
    </Link>
    .
  </p>
);

const Verdict = ({
  tone,
  heading,
  blurb,
}: {
  tone: string;
  heading: string;
  blurb: string;
}) => (
  <div className="flex items-center gap-3.5">
    <Coil tone={tone} />
    <div>
      <p className="font-display text-xl font-semibold tracking-tight">
        {heading}
      </p>
      <p className="mt-1.5 text-[13px] leading-relaxed text-muted">{blurb}</p>
    </div>
  </div>
);

export const ResultView = ({
  outcome,
}: {
  outcome: NonNullable<OcrOutcome>;
}) => {
  if (outcome.status === "error") {
    return (
      <div className="mx-auto w-full max-w-md px-5 py-8">
        <p className="font-display text-2xl font-semibold tracking-tight">
          Something went wrong
        </p>
        <p className="mt-2 text-[13px] leading-relaxed text-muted">
          We&apos;re not sure why. Try again, and make sure the photo shows the
          ingredients list.
        </p>
      </div>
    );
  }

  if (outcome.status === "cool") {
    return (
      <div className="mx-auto w-full max-w-md px-5 py-8">
        <Verdict
          tone="stroke-ok"
          heading="Clear"
          blurb="None of the ingredients we read are on the avoid list."
        />
        <GrowLine />
      </div>
    );
  }

  const flagged = outcome.groups.filter((g) => g[0]);
  const total = flagged.reduce((n, g) => n + g.length, 0);

  return (
    <div className="mx-auto w-full max-w-md px-5 py-8">
      {/* Heading carries the verdict, in the same words the search badges use.
          The count belongs in the blurb — "3 to avoid" reads as a quantity
          where the user is looking for an answer. */}
      <Verdict
        tone="stroke-bad"
        heading="Skip this one"
        blurb={`We read ${total} ingredient${
          total === 1 ? "" : "s"
        } that aren't compatible with the Curly Girl method.`}
      />

      <div className="mt-3 border-t border-line">
        {flagged.map((group, i) => (
          <AccordionSection key={i} title={group[0].type} count={group.length}>
            <ul>
              {group.map((result, item) => (
                <IngredientRow key={item} position={item + 1} name={result.name} />
              ))}
            </ul>
          </AccordionSection>
        ))}
      </div>

      <GrowLine />
    </div>
  );
};
