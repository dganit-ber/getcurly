# Rewrite plan

The app is live at getcurly.ink and the scan pipeline works. What's changing is the
**shape of the flows** and the **look**, and both are big enough that patching costs
more than rebuilding the surface. The database, the Vision integration and the
ingredient matcher are worth keeping.

## What survives

- The Google Cloud Vision call and the image upload guards (size cap, MIME check,
  per-IP rate limit). Move the rate limit onto `check_rate_limit` so it shares a
  ledger with the other write paths.
- The ingredient matching logic — but move the normalization and lookup into the
  database (`normalize_ingredient`, `match_ingredient`) so the same rules apply from
  the app, from a backfill script, and from SQL you run by hand.
- The Open Beauty Facts import and its `source = 'obf'` marker. Its GTINs are the
  reason barcode lookup works on day one.
- `products` as a table. Everything else in the schema is added by
  `db/getcurly-schema.sql`.

## What goes

- **The verdict gating.** Anything that asks the user for input before showing an
  answer. Rule 1.
- **Every per-ingredient uncertainty affordance** — confidence badges, "we're not
  sure", warning icons on rows. Rule 2.
- **The pre-scan framing warnings.** Rule 4.
- **The old design system**: kelp green, Fraunces/Karla, the freshness-intensity
  badges. Replaced by `app/theme.css`. The freshness *idea* survives as an explicit
  date (`last_checked_at`), not as colour intensity — a date she can read beats a
  badge only you can decode.
- `UnderConstruction` on `/search`. It becomes `/library`, built for real.

## Order of work

**Each step is written out in full in `steps/`.** Read `steps/00-before-you-start.md`
first, then work through them in order. Every step is written to leave the app
deployable — finish one, ship it, check it on a phone, then start the next.

| # | Step | Ships |
|---|---|---|
| 01 | `steps/01-schema.md` | nothing visible — the foundation |
| 02 | `steps/02-theme-and-shell.md` | new look over the old pages |
| 03 | `steps/03-ingredient-dictionary.md` | nothing visible — matching quality |
| 04 | `steps/04-label-flow.md` | scan → verdict, the core of the app |
| 05 | `steps/05-optional-tail.md` | edit the list, name the bottle |
| 06 | `steps/06-barcode.md` | two-second answers |
| 07 | `steps/07-mismatch-path.md` | reformulation diffs |
| 08 | `steps/08-new-products.md` | the library grows |
| 09 | `steps/09-library.md` | browse and search |
| 10 | `steps/10-affiliates.md` | revenue, model A only |
| 11 | `steps/11-articles.md` | content and SEO |

Steps 01 and 03 ship nothing a user can see. Do them first anyway — everything from
04 onwards assumes `products.type` is a closed list and the ingredient dictionary is
good enough to match against.

## Things that will bite

- **`position` is reserved** in a Postgres `returns table` list. The column is
  `scan_ingredients.pos`. Don't rename it back.
- **Tailwind v4 `@theme inline`** — without `inline` the dark palette silently stops
  working, because Tailwind copies the resolved value instead of the `var()`.
- **`BarcodeDetector` isn't everywhere.** Feature-detect and fall back to
  `zxing-wasm`. Don't assume iOS Safari has it.
- **Don't re-sort `cg_safe_alternatives`.** The order *is* the rule (match, then
  price, never commission). Sorting it in the component breaks the promise in the
  disclosure text.
- **`product_confidence()` before any verdict pill** on a product page. Every time.
- **Vision costs money per call; barcode decoding doesn't.** Anything that can be
  answered from a barcode should be.
- **Hash IPs.** `IP_HASH_SALT` must be set in Vercel, and a raw IP must never reach
  the database or a log line.

## Environment

```
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=        # server only, never in a client component
GOOGLE_APPLICATION_CREDENTIALS_JSON=   # project get-curly-507116
IP_HASH_SALT=                     # any long random string, keep it stable
AFFILIATE_MODEL=a                 # a | b | c
```
