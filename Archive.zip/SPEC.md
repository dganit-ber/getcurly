# Screens, routes and states

Visual reference: `getcurly-prototype.html` — open it in a browser. It is a
**reference, not source**. It contains a fake screen router, an annotation rail and
inline styles; none of that should survive into the app. What to take from it: layout,
spacing, component shapes, and the copy.

Flow diagram: `GetCurly-flows.svg`.

---

## Routes

| Route | Rendering | What it is |
|---|---|---|
| `/` | Server | Home. Two scan CTAs, search, the six groups, how it works, library counts, article teasers, footer disclosure. |
| `/scan` | Client | The camera. `?mode=barcode\|label`, barcode default. One viewfinder, both detectors running. |
| `/s/[scanId]` | Server | Verdict from a **label** scan. The scan is the subject, so the URL is shareable and screenshot-friendly. |
| `/s/[scanId]/list` | Client | Optional. "What we counted" — the resolved list, editable, with re-run. |
| `/s/[scanId]/name` | Client | Optional. Name the bottle: fingerprint candidates, then the add form. |
| `/p/[id]` | Server | Product page. A **barcode** scan lands here with `?from=barcode`. Verdict, caution, last-checked, the stored list, the three check buttons. |
| `/p/[id]/changed` | Server | The diff, after a mismatch rescan. Reads `latest_product_diff`. |
| `/new` | Server | Barcode we don't know. `?barcode=…`. Two routes on: photos or manual. |
| `/new/photos` | Client | Two-shot capture: ingredients, then front. |
| `/new/add` | Client | The add form: barcode (attached, read-only), brand, name, **type**, size. |
| `/library` | Server | Browse confirmed products. Replaces the parked `/search`. |
| `/read` · `/read/[slug]` | Server | Article index and article. |
| `/method` | Server | How the method works, how verification works, the affiliate promise. |
| `/picks` | — | Only exists if affiliate model B is chosen. **Off by default.** |

### Route handlers

All of these hash the IP, call `check_rate_limit`, and use the service role.

| Handler | Does |
|---|---|
| `POST /api/scan/label` | image → Vision OCR → split + match each ingredient → `record_label_scan` → `{ scanId, verdict }` |
| `POST /api/scan/front` | image → Vision OCR → best-guess `{ brand, name, type }` for the add form to prefill |
| `POST /api/scans/[id]/resolve` | she picked a candidate → `fork_scan` → update the row → recompute → `{ scanId, verdict }` |
| `POST /api/scans/[id]/list` | she edited the list → `fork_scan` → apply edits → recompute → `{ scanId, verdict }` |
| `POST /api/products/[id]/check` | `{ result: 'match' \| 'stale' }` → `log_product_check` |
| `POST /api/products` | create a listing: brand, name, type, barcode, optional scanId |

Barcode **lookup** needs no handler — a Server Component can select by barcode with
the anon key, since reads are open.

---

## Screen by screen

### `/` Home
Order matters; it was argued over.

1. Hero: the question in her words, then two buttons. **Scan the barcode** (primary,
   "two seconds, if we've met it before") and **Read the ingredients** ("slower, and
   it can't be out of date"). Then a search field.
2. Privacy microcopy: no account, photo isn't kept.
3. "Barcode or label?" — a barcode tells us *which* product, only the label tells us
   *what's in it today*.
4. The six groups as chips: five ruled out, CG-safe in green.
5. How it goes, three numbered steps (it is a real sequence).
6. Library counts — products with barcodes vs confirmed by a real scan. **Pull these
   live**; a hardcoded number undoes the honesty the rest of the page trades on.
7. Three article titles with kickers.
8. Footer: the affiliate promise.

Not on this page: sign-up wall, scan counter, testimonials.

### `/scan`
- Mode switch (Barcode / Ingredients list), barcode selected by default.
- One viewfinder. Reticle short for a barcode, tall for a paragraph.
- Barcode resolves on-device and navigates immediately — no confirm step.
- Label: capture → `POST /api/scan/label` → redirect to `/s/[scanId]`.
- Processing state is narrated with the real steps and the ingredient count. Show the
  **cleaned** list forming, never the raw OCR string with its typos.
- Failure states, all three distinct:
  - under ~10 items → no verdict. "We only caught part of the list" + retake.
  - no text → retake, and this is the one place a framing hint belongs.
  - Vision down → "our reader is out — search for it by name instead", search open.

### `/s/[scanId]` Label verdict
1. Verdict block: word, icon, colour, one sentence. Readable at arm's length.
2. **Only if `scan_open_questions` returns a row**: the pick card. Which word, what
   each candidate means, three buttons (both candidates + "can't tell").
3. Product identity: "Looks like X" with a *not right?* link if the fingerprint
   matched; "A bottle we don't know yet" if it didn't — and in that case the
   **"want to add it?"** prompt goes immediately underneath.
4. On a Skip: the flagged ingredients, three lines each — name, group + position,
   what it does to curls. Then the cleared groups collapsed into one row.
   On a Clear: all five groups ticked, then "worth knowing" (the CG-safe matches,
   including the behentrimonium methosulfate explainer).
5. "What we counted" preview — six rows and a count, with a link to the full list.
   Caption: computers misread small print, compare it if you want.
6. Evidence note: first read vs confirmed, and what that means.
7. Affiliate block — see the matrix below.
8. Scan another / save to shelf / "tell us what went wrong".

### `/s/[scanId]/list` What we counted
Flat list, no flags, no badges of doubt. Number, resolved name, group pill where we
matched one, delete. Twelve rows then "show the remaining N". Tap a row to edit
inline. "Add one we missed" in the header. Primary button **Work out my verdict
again**, live only once something changed. Footer: *nothing here is required — your
verdict already stands.*

### `/p/[id]` Barcode verdict
1. Verdict — **unless** tier is `seed_only` or `no_list`, in which case no verdict
   pill at all (rule 7).
2. Caution: manufacturers change ingredients.
3. Identity, then **Ingredients last checked: \<date\> · N months ago, by N people**.
4. The stored list, in label order, first six plus a count.
5. The question: *does this match the bottle in your hand?* Three buttons —
   **It matches** (→ `check`, then a confirmation screen showing the date moving),
   **It doesn't match** (→ `/scan?mode=label&for=[id]`), **Not now** (nothing happens).
6. Affiliate block on a Skip only.

### `/p/[id]/changed` What changed
Four-ish rows: `gone` / `new` / `moved`, positions named, "the other N are unchanged".
Then what it means for the verdict — *"Still Skip, but for one reason now, not two"* —
then that her read is the record now and the old list is kept.

### `/new` Barcode we don't know
Barcode shown. "You'd be product N+1", anonymous, waits for a second agreement.
Two option cards: **Take two photos** (quickest, pushed) and **Add it yourself**
(if the front is awkward). Plus a free exit: "Not now", no guilt.

### `/new/photos`
Two numbered cards, first already ticked with what it produced ("37 ingredients
read"). Second explains *why* the front is needed: brand, name, type. Then **Create
the listing**, and "skip the front — I'll type it".

### `/new/add`
Barcode row first, stated as already attached. Brand (autocomplete, 373 brands,
fuzzy). Product name. **Type** — required, `<select>` from `product_types`. Size,
optional. Whatever front-of-bottle OCR read arrives prefilled and she confirms it;
**type is never saved on a guess** — a shampoo filed as a conditioner sends the wrong
product to the next person.

---

## Affiliate block matrix

Model A is the default and the one to ship. B and C are behind a config flag
(`AFFILIATE_MODEL` env or a row in a settings table) so you can switch without a
rewrite.

| Screen | A · Contextual (default) | B · + Shop hub | C · Minimal |
|---|---|---|---|
| Barcode **Skip** | Two exact alternatives + disclosure | Same + a picks strip | "What to look for instead" + a library link |
| Barcode **Clear** | Quiet "where to buy" | Where to buy + picks strip | Plain stockist line |
| Label **Skip** | Two alternatives | Same + picks strip | What to look for instead |
| Label **Clear**, known product | Quiet "where to buy" | + picks strip | Plain stockist line |
| Label **Clear**, unknown product | **Recommendations only, no buy link** | Recommendations + picks | "Nothing to sell you here" |
| Nav | no extra item | adds "Picks" | no extra item |

The barcode Skip is the best slot in the product: identity is certain so the
alternatives are exact, and she spent two seconds rather than ninety. If only one
affiliate surface gets built, build that one.

---

## Components

Stateless unless noted. All take their colours from the theme tokens.

```
components/
  VerdictPill.tsx        clear | skip — pill, icon, word. The only place those colours appear.
  CautionNote.tsx        the amber/indigo "manufacturers change ingredients" block
  LastChecked.tsx        date + "N months ago, by N people". Reads product_confidence().
  IngredientRow.tsx      number, name, group pill, optional delete/edit
  IngredientList.tsx     read-only preview (verdict screens) and editable (list screen)
  FlaggedIngredient.tsx  three-line explanation of one flagged ingredient
  PickCard.tsx           the one interruption. Renders only from scan_open_questions.
  Viewfinder.tsx         "use client" — camera, both detectors, reticle short|tall
  ModeSwitch.tsx         barcode | ingredients list
  BrandAutocomplete.tsx  "use client" — 373 brands, fuzzy, shows near misses
  TypeSelect.tsx         closed list from product_types
  AlternativesBlock.tsx  affiliate block, model-aware. Owns the disclosure text.
  DiffRow.tsx            gone | new | moved
  ShotCard.tsx           the two-photo progress card
  StatTile.tsx           the two library counts
  WaveDivider.tsx        the section divider (a curl, not decoration)
```
