# Get Curly

A tool for someone standing in a drugstore aisle holding a bottle, who wants to know
whether it fits the Curly Girl method. She points her phone at it and gets **Clear**
or **Skip**. Everything else in the app is optional.

Live at getcurly.ink. This is a rewrite of a deployed app — see `REWRITE-PLAN.md`.

**Audience: women, mostly early twenties to late thirties.** Not developers, not
chemists. She knows the method, or is learning it. She is in a shop, on a phone, in a
hurry, and she has no account.

---

## Hard rules

These are product decisions, already made. Do not relitigate them in code.

1. **Verdict in one action.** Scan → answer. Nothing stands between the camera and
   the verdict: no login, no form, no confirmation step, no "which product is this?".
   Every other interaction in the app is an optional second tap.

2. **Never surface OCR confidence.** No "we're not sure about this" badges, no
   per-row warning icons, no confidence percentages, no wavy underlines on
   individual ingredients. Our matching certainty is a database concern. One general
   sentence covers it: *computers misread small print, change anything that's wrong.*

3. **Interrupt after the verdict only when it would change.** Exactly one condition:
   a word we couldn't read cleanly whose candidate matches disagree on the verdict.
   Then ask her to pick, with the candidates named and what each one means.
   - Could matter but no plausible candidates → the general note, no interaction.
   - Cannot change the verdict → say nothing at all. Most misreads land here.
   Use `scan_open_questions(scan_id)`; it returns rows only in that first case.

4. **No warnings before a scan.** Don't tell her to "hold it flat" or that the read
   might fail. Most bottles aren't flat and most reads are fine. A framing hint
   belongs only on an actual failure, where it's actionable.

5. **Show what we counted, not what we read.** The optional list screen shows
   *resolved* names — if OCR read "Cetearyl Alcohoi" and we matched cetearyl alcohol,
   she sees cetearyl alcohol. In label order, numbered, every row editable. Position
   is roughly concentration; never re-sort it.

6. **A barcode answer always carries its age.** Verdict, then "manufacturers change
   ingredients — they reformulate and keep the same barcode", then
   **Ingredients last checked: \<date\>**, shown every single time, for everyone.

7. **Seed data gets no verdict.** A barcode hit on an unscanned Open Beauty Facts row
   (`product_confidence().tier = 'seed_only'`) must not render a verdict pill. Show
   "we have a list for this, but nobody's checked it", the ingredients as a preview,
   and reading the label as the primary action. A wrong Clear on a shampoo someone
   then buys is the one failure that would really cost us.

8. **A mismatch needs a photo.** "It doesn't match" cannot go straight to a diff —
   she photographs the current label first. Without a photo it's a `stale` flag, a
   weaker signal, recorded but never enough to rewrite a verdict.

9. **A barcode is not a product.** A new barcode needs brand, name and **type**
   before it's a listing. Type comes from the closed `product_types` list, never
   free text — it's what makes "a cleanser that does the same job without a sulfate"
   possible.

10. **Nothing is published on submit.** A user-added product or a fresh scan is
    evidence until a second scan agrees (`maybe_promote_product`). Say so in the UI.

11. **Scans are append-only.** An edit calls `fork_scan`, never an update. We keep
    the pair — what the machine read, what a person corrected — as training data for
    `ingredient_aliases`. She never sees that pair.

12. **Affiliate rules, non-negotiable:**
    - Ranked by how well they match the method, then by price. **Never by commission.**
      Say so in the disclosure, in those words.
    - Only products a real scan has confirmed. Seed rows can be searched, not sold.
    - No stockist link for a product we can't name. Recommendations are fine there;
      a buy link for an unidentified bottle is not.
    - No alternatives on a **Clear**. She's holding something that works.
    - Disclosure sits in the same block as the links, before the click.
    - A verdict never changes because of a commission. This is in the footer as a promise.

13. **Anonymous, and it stays that way.** No account for scanning, checking, editing
    or adding. `created_by` is nullable. Hash the IP (`sha256(ip + SALT)`) for rate
    limiting and never store it raw.

14. **Two verdicts only.** `clear` and `skip`. A third "avoid" tier was considered
    and dropped.

---

## Stack

- **Next.js 15** (App Router), TypeScript, deployed on Vercel
- **Supabase** (Postgres, Frankfurt) — schema in `db/getcurly-schema.sql`
- **Google Cloud Vision** for OCR (project `get-curly-507116`)
- **Tailwind v4** with CSS custom properties — see `app/theme.css`
- **Lucide React** for icons
- Barcode decoding **client-side**: `BarcodeDetector` where available,
  `zxing-wasm` as fallback. No upload, no Vision call, no cost.
- **No Radix, no MUI, no component library.** Plain Tailwind.

## Conventions

- Named arrow function exports: `export const ProductCard = () => {}`.
  Exception: Next.js pages and layouts, which need `export default`.
- Server Components by default. `"use client"` only where there's camera, form state
  or a theme toggle.
- All writes go through a route handler or server action that hashes the IP and calls
  `check_rate_limit` before touching data. Never write from the client with the anon
  key directly.
- Copy lives in `lib/copy.ts`. Don't inline user-facing strings in components —
  the wording carries the rules in rule 2, 6 and 12.
- Colours come from the theme tokens only. Never a hex literal in a component, and
  never a colour whose only definition is inside a dark-mode block.
- Semantic colour (clear/skip/caution) is separate from the accent and is never the
  only signal — always paired with an icon and a word.

## Tone

Warm, second person, plain. "Is this bottle good for **your curls**?" not
"Analyse product compatibility". It states what it knows and what it doesn't — that
honesty is the whole asset. No exclamation marks, no "Oops!", no emoji.

Errors say what happened and what to do: *"We only caught part of the list — try the
photo again"*, never *"Something went wrong"*.
