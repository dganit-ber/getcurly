# Get Curly — rewrite handoff

Drop the whole folder into the repo root. Read in this order:

1. **`CLAUDE.md`** → move to the repo root as `CLAUDE.md`. The hard rules. Read first, and
   re-read before changing anything about verdicts, OCR feedback or affiliate blocks.
2. **`REWRITE-PLAN.md`** → what survives from the deployed app, what goes, and the
   order to build in.
3. **`steps/`** → the eleven steps written out, one file each: goal, tasks with file
   paths, checkable done-criteria, and the specific traps for that step. Start with
   `steps/00-before-you-start.md`. Do one at a time and deploy between them.
4. **`SPEC.md`** → routes, route handlers, every screen's content and states, the
   affiliate matrix, the component list.
5. **`db/getcurly-schema.sql`** → run it in the Supabase SQL editor. One transaction,
   safe to re-run. Step 1 of the plan.
6. **`app/theme.css`** and **`app/fonts.ts`** → the design tokens. No hex literals in
   components, ever.
7. **`lib/db.types.ts`**, **`lib/api.ts`**, **`lib/copy.ts`** → the data contracts, the
   server-side write wrappers (IP hashing and rate limiting included), and every
   user-facing string.
8. **`reference/getcurly-prototype.html`** → open it in a browser. **Visual reference,
   not source.** It has a fake screen router, an annotation rail beside the phone, and
   inline styles. Take the layout, the component shapes and the copy; take none of the
   plumbing. The notes rail explains the reasoning behind each screen — worth reading
   once, then working from `SPEC.md`.
9. **`reference/GetCurly-flows.svg`** → the three flows as a diagram.

Not included on purpose: the PDF of all the screens. Everything in it is in the
prototype HTML, in a form that's actually readable by a coding agent.
